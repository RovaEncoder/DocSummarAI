import React from 'react';
import { Cpu, Shield, Zap, Users } from 'lucide-react';

const features = [
  {
    icon: Cpu,
    title: 'Advanced Processing',
    description: 'State-of-the-art neural networks for complex problem solving'
  },
  {
    icon: Shield,
    title: 'Secure & Private',
    description: 'Enterprise-grade security with end-to-end encryption'
  },
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Optimized performance with real-time processing capabilities'
  },
  {
    icon: Users,
    title: 'Collaborative',
    description: 'Seamless team integration and multi-user support'
  }
];

export function Features() {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">Powerful Features</h2>
          <p className="text-gray-600">Discover what makes SummarizeAI stand out from the rest</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <feature.icon className="w-12 h-12 text-black mb-4" />
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}