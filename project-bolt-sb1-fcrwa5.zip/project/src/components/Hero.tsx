import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function Hero() {
  const navigate = useNavigate();

  return (
    <section className="pt-32 pb-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-black mb-6">
            Summarize Documents
            <br />
            <span className="text-gray-600">In Seconds</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Transform lengthy documents into clear, concise summaries with SummarizeAI.
            Save time and extract key insights instantly.
          </p>
          <button 
            onClick={() => navigate('/summarize')}
            className="bg-black text-white px-8 py-4 rounded-full inline-flex items-center space-x-2 hover:bg-gray-800 transition-colors"
          >
            <span>Try It Now</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
        <div className="mt-16 relative">
          <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1664575602276-acd073f104c1?auto=format&fit=crop&q=80"
                alt="Original Document"
                className="rounded-xl shadow-2xl w-full h-[400px] object-cover"
              />
              <div className="absolute bottom-4 left-4 bg-black/80 text-white px-4 py-2 rounded-lg">
                Original Document
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1453928582365-b6ad33cbcf64?auto=format&fit=crop&q=80"
                alt="Summarized Version"
                className="rounded-xl shadow-2xl w-full h-[400px] object-cover"
              />
              <div className="absolute bottom-4 right-4 bg-black/80 text-white px-4 py-2 rounded-lg">
                Summarized Version
              </div>
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent rounded-xl"></div>
        </div>
      </div>
    </section>
  );
}