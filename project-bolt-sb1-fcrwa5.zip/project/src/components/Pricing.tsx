import React from 'react';
import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Basic',
    price: '$9',
    period: 'per month',
    features: [
      'Up to 100 pages/month',
      'Basic summaries',
      'Email support',
      'Export to PDF'
    ]
  },
  {
    name: 'Pro',
    price: '$29',
    period: 'per month',
    features: [
      'Up to 1000 pages/month',
      'Advanced summaries',
      'Priority support',
      'Export to all formats',
      'Team collaboration'
    ],
    popular: true
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: 'contact us',
    features: [
      'Unlimited pages',
      'Custom AI models',
      'Dedicated support',
      'API access',
      'Advanced analytics',
      'Custom integration'
    ]
  }
];

export function Pricing() {
  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">Simple, Transparent Pricing</h2>
          <p className="text-gray-600">Choose the plan that works best for you</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`relative bg-white p-8 rounded-xl ${
                plan.popular 
                  ? 'ring-2 ring-black shadow-xl' 
                  : 'border border-gray-200 shadow-sm'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-8 transform -translate-y-1/2">
                  <div className="bg-black text-white px-4 py-1 rounded-full text-sm">
                    Most Popular
                  </div>
                </div>
              )}
              
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-600">/{plan.period}</span>
                </div>
              </div>
              
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-black" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`w-full py-3 rounded-lg transition-colors ${
                plan.popular
                  ? 'bg-black text-white hover:bg-gray-800'
                  : 'bg-gray-100 text-black hover:bg-gray-200'
              }`}>
                Get Started
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}