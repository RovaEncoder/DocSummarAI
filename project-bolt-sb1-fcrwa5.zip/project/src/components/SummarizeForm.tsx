import React, { useState } from 'react';
import { Settings, RefreshCw } from 'lucide-react';
import { FileUpload } from './FileUpload';
import { AdvancedOptions } from './AdvancedOptions';

interface SummarizeFormProps {
  files: File[];
  onFilesChange: (files: File[]) => void;
  isProcessing: boolean;
  onSummarize: () => void;
  preferences: string;
  onPreferencesChange: (value: string) => void;
}

export function SummarizeForm({
  files,
  onFilesChange,
  isProcessing,
  onSummarize,
  preferences,
  onPreferencesChange,
}: SummarizeFormProps) {
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);

  return (
    <div className="space-y-8">
      <FileUpload files={files} onFilesChange={onFilesChange} />

      <div className="space-y-4">
        <div className="bg-gray-50 p-6 rounded-xl">
          <label htmlFor="preferences" className="block text-sm font-medium text-gray-700 mb-2">
            Summarization Preferences
          </label>
          <textarea
            id="preferences"
            rows={4}
            value={preferences}
            onChange={(e) => onPreferencesChange(e.target.value)}
            placeholder="Explain how you want the document to be summarized. For example: 'Focus on key findings and methodology' or 'Summarize main arguments and conclusions'"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent resize-none"
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => setShowAdvancedOptions(true)}
            className="flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Settings className="w-5 h-5" />
            <span>Advanced Options</span>
          </button>

          <button
            onClick={onSummarize}
            disabled={files.length === 0 || isProcessing}
            className={`flex-1 flex items-center justify-center space-x-2 px-6 py-2 rounded-lg text-white transition-colors
              ${files.length === 0 ? 'bg-gray-300 cursor-not-allowed' : 'bg-black hover:bg-gray-800'}`}
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <span>Summarize Documents</span>
            )}
          </button>
        </div>
      </div>

      <AdvancedOptions
        isOpen={showAdvancedOptions}
        onClose={() => setShowAdvancedOptions(false)}
        onSelectPreset={onPreferencesChange}
      />
    </div>
  );
}