import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { SummarizeForm } from '../components/SummarizeForm';
import { summarizeText } from '../services/summarization';

interface SummaryResult {
  fileName: string;
  summary: string;
}

export function SummarizePage() {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [preferences, setPreferences] = useState('');
  const [summaries, setSummaries] = useState<SummaryResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Check API key on component mount
    if (!import.meta.env.VITE_HUGGINGFACE_API_KEY) {
      setError('Hugging Face API key is not configured. Please check your .env file.');
    }
  }, []);

  const handleSummarize = async () => {
    if (files.length === 0) return;
    
    setIsProcessing(true);
    setError(null);
    setSummaries([]);

    try {
      const newSummaries: SummaryResult[] = [];

      for (const file of files) {
        if (file.size > 1024 * 1024) { // 1MB limit
          throw new Error(`File ${file.name} is too large. Please use files under 1MB.`);
        }

        const text = await file.text();
        if (text.length > 10000) {
          throw new Error(`File ${file.name} content is too long. Please use shorter documents.`);
        }

        const summary = await summarizeText(text, preferences);
        newSummaries.push({
          fileName: file.name,
          summary
        });
      }

      setSummaries(newSummaries);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => navigate('/')}
          className="flex items-center space-x-2 text-gray-600 hover:text-black transition-colors mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Home</span>
        </button>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-black mb-4">
            Upload Your Documents
          </h1>
          <p className="text-gray-600">
            Get instant summaries of your documents using our advanced AI
          </p>
        </div>

        <SummarizeForm
          files={files}
          onFilesChange={setFiles}
          isProcessing={isProcessing}
          onSummarize={handleSummarize}
          preferences={preferences}
          onPreferencesChange={setPreferences}
        />

        {error && (
          <div className="mt-8 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600">
            {error}
          </div>
        )}

        {summaries.length > 0 && (
          <div className="mt-12 space-y-8">
            <h2 className="text-2xl font-bold text-black">Summaries</h2>
            {summaries.map((result, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold mb-4">{result.fileName}</h3>
                <p className="text-gray-600 whitespace-pre-wrap">{result.summary}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}