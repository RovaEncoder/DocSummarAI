import { HfInference } from '@huggingface/inference';

const hf = new HfInference(import.meta.env.VITE_HUGGINGFACE_API_KEY);

export async function summarizeText(text: string, preferences: string): Promise<string> {
  try {
    if (!import.meta.env.VITE_HUGGINGFACE_API_KEY) {
      throw new Error('Hugging Face API key is not configured');
    }

    const prompt = `Summarize the following text according to these preferences: ${preferences}\n\nText: ${text}`;
    
    const response = await hf.textGeneration({
      model: 'facebook/bart-large-cnn',
      inputs: prompt,
      parameters: {
        max_length: 500,
        min_length: 100,
        temperature: 0.7,
        top_p: 0.95
      }
    });

    if (!response.generated_text) {
      throw new Error('No summary was generated');
    }

    return response.generated_text;
  } catch (error) {
    console.error('Summarization error:', error);
    if (error instanceof Error) {
      if (error.message.includes('401')) {
        throw new Error('Invalid or expired API key. Please check your Hugging Face API key.');
      } else if (error.message.includes('429')) {
        throw new Error('Rate limit exceeded. Please try again later.');
      }
    }
    throw new Error('Failed to summarize text. Please check your API key and try again.');
  }
}